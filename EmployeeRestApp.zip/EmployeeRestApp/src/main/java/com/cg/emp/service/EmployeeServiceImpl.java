package com.cg.emp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.spel.ast.OpAnd;
import org.springframework.stereotype.Service;

import com.cg.emp.beans.Employee;
import com.cg.emp.dao.EmployeeRepository;
import com.cg.emp.exception.EmployeeException;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public List<Employee> getAllEmployees() throws EmployeeException {

		try {
			return employeeRepository.findAll();
		} catch (Exception e) {
			throw new EmployeeException(e.getMessage());

		}
	}

	@Override
	public List<Employee> addEmployee(Employee emp) throws EmployeeException {
	
		if(employeeRepository.existsById(emp.getId())) {
		throw new EmployeeException("Employee with Id "+emp.getId()+"already exist");
		}
		employeeRepository.save(emp);
		return getAllEmployees();

	}

	@Override
	public Employee getEmployeeById(int id) throws EmployeeException {
		/*Optional<Employee> o= employeeRepository.findById(id);
		if(!o.isPresent()) {
			throw new EmployeeException("Employee with Id"+id+"does not exist");
		}
		*/
		if(!employeeRepository.existsById(id)) {
			throw new EmployeeException("Employee with Id"+id+"does not exist");
		}
		return employeeRepository.findById(id).get();
				
	}

	@Override
	public List<Employee> deleteEmployee(int id) throws EmployeeException {
		if(!employeeRepository.existsById(id)) {
			throw new EmployeeException("Employee with Id"+id+"does not exist");
		}
		employeeRepository.deleteById(id);
		return getAllEmployees();
	}

	@Override
	public List<Employee> updateEmployee(Employee emp) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}

}
