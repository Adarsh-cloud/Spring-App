package com.cg.emp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.emp.beans.Employee;
@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Integer>{

}
